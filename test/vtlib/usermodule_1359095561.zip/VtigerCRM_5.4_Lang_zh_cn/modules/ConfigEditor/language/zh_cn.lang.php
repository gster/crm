<?php

$mod_strings = Array (
	
	'ConfigEditor' => '编辑配置',
	'LBL_CONFIG_EDITOR' => '编辑配置',
	'LBL_SETTINGS' => '设置',
	'LBL_CONFIG_EDIT'=>'编辑vtigerCRM的配置细节',
	'SINGLE_ConfigEditor' => '编辑配置',
	'LBL_TRUE'=> 'true',
	'LBL_FALSE'=> 'false',
	'LBL_MAX_UPLOAD_SIZE_MSG'=> '最大上载大小为 5MB',
	'LBL_INVALID_EMAIL_MSG'=>'无效的电子邮件地址',
	'LBL_EMPTY_NAME_MSG'=> '支持名称不能为空',
	'LBL_MAX_LISTVIEW_ENTRIES_MSG'=>'ListView中的最大项目是100',
	'LBL_MAX_HISTORY_VIEWED_MSG'=>'请输入范围1-5',
	'LBL_MAX_TEXTLENGTH_LISTVIEW_MSG'=>'最大文本长度为100',
	'LBL_MB'=>'MB',
	'LBL_MINI_CALENDAR_DISPLAY' => '迷你日历显示',
	'LBL_WORLD_CLOCK_DISPLAY'=>'世界时钟显示',
	'LBL_CALCULATOR_DISPLAY'=>'计算器显示',
	'LBL_USE_RTE'=>'使用 RTE',
	'LBL_HELPDESK_SUPPORT_EMAILID'=>'帮助支持mail',
	'LBL_HELPDESK_SUPPORT_NAME'=>'帮助支持姓名',
	'LBL_MAX_UPLOAD_SIZE'=>'上传最大尺寸  (Max 5MB)',
	'LBL_MAX_HISTORY_VIEWED'=>'最大历史浏览',
	'LBL_DEFAULT_MODULE'=>'缺省模块',
	'LBL_MAX_TEXT_LENGTH_IN_LISTVIEW'=>'最大在ListView的文本长度',
	'LBL_MAX_ENTRIES_PER_PAGE_IN_LISTVIEW'=>'最大在ListView每页的条目',
	'LBL_CONFIG_FILE'=>'config.inc.php',
	'LBL_CONFIG_EDIT_CAUTION_INFO' =>'您正在编辑vtigerCRM的配置细节.',
	'LBL_DOUBLE_CHECK_INFO'=>'请仔细检查，在保存的值。',
	'LBL_HELP_INFO'=>"这是作为一个'从电子邮件'，对他的登录凭据创建一个新的用户发送邮件，
					麻烦有关分配的机票票所有者发送邮件，发送有关提醒和通知的邮件.",

);

?>