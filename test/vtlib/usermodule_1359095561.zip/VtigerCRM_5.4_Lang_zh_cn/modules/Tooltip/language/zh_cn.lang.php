<?php
/*********************************************************************************
** The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
* 
 ********************************************************************************/

$mod_strings = Array (
'Tooltip' => '信息提示',
'LBL_TOOLTIP_MANAGEMENT'=>' 信息提示管理',
'LBL_TOOLTIP_MANAGEMENT_DESCRIPTION'=>'管理提示信息',
'LBL_FIELDS_IN'=>'字段',
'LBL_TOOLTIP_HELP_TEXT'=>'选择你想显示在信息提示的字段',
'LBL_FIELD'=>'字段',

);

?>
