<?php
/*+**********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 ************************************************************************************/

$mod_strings = Array(
'RecycleBin' => '回收站',
'MSG_EMPTY_RB_CONFIRMATION'=>'您确定要从数据库中永久删除这些记录?',
'LBL_SELECT_MODULE'=>'选择模块',
'LBL_EMPTY_MODULE'=>'没有找到记录',
'LBL_MASS_RESTORE'=>'还原',
'LBL_EMPTY_RECYCLEBIN'=>'清空回收站',
'LNK_RESTORE'=>'还原',
'LBL_NO_PERMITTED_MODULES'=>'没有可用模块',
);

?>