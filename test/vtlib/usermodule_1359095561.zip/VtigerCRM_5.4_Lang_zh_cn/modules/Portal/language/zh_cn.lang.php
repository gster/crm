<?php
/*********************************************************************************
** The contents of this file are subject to the vtiger CRM Public License Version 1.0
* ("License"); You may not use this file except in compliance with the License
* The Original Code is:  vtiger CRM Open Source
* The Initial Developer of the Original Code is vtiger.
* Portions created by vtiger are Copyright (C) vtiger.
* All Rights Reserved.
*
********************************************************************************/

$mod_strings = Array(
// added for 5.0 beta
  'LBL_BOOKMARKED_URL' => '网址',
'LBL_MANAGE_BOOKMARKS' => '管理书签',
'LBL_BOOKMARK_LIST' => '书签列表',
'LBL_MY_BOOKMARKS' => '我的书签',
'LBL_NEW_BOOKMARK' => '新增书签',
'LBL_BOOKMARK' => '书签',
 'LBL_NAME' => '名称：',
  'LBL_URL' => '网址：',
'LBL_ADD' => '新增',
'LBL_SNO' => '#',
  'LBL_BOOKMARK_NAME_URL' => '书签名称和网址',
  'LBL_TOOLS' => '操作',
  'LBL_MANAGE_SITES' => '管理书签',
  'LBL_MY_SITES' => '我的书签',
// Added/Updated for vtiger CRM 5.0.4
//added as an enhancement
  'LBL_SET_DEFAULT_BUTTON' => '设为默认',

);
?>
