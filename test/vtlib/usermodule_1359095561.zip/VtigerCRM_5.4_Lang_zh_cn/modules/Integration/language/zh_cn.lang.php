<?php
$mod_strings = Array (
'Integration' => '合并',
'SINGLE_Integration' => '合并',

'LBL_HOW_TO_USE' => '如何使用',

);

?>
