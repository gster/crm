<?php
/*+*******************************************************************************
 *  The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 *
 *********************************************************************************/
$mod_strings = array(
	'LBL_CREATE_ZIP_FAILURE' => '创建ZIP文件失败',
	'LBL_ZIP_FILE_ADD_FAILURE' => '添加文件失败',
	'LBL_FTP_CONNECT_FAILED' => 'FTP 连接失败',
	'LBL_FTP_LOGIN_FAILED' => 'FTP 登录失败',
);

?>