<?php
class qCal_DateTime_Recur_Rule_BySecond extends qCal_DateTime_Recur_Rule {

	public function getRecurrences() {
	
		return array();
	
	}

}